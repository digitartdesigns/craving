$(document).ready(function() {
var url = "http://craving.webdesigncoquitlam.com";    
$(location).attr('href',url);
});
